

class SmithGUI {

    public static void main(String[] args) {
        MainScreen ms = new MainScreen();

    }

}